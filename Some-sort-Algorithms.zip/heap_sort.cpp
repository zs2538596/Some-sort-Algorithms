/*
	���˲��ͣ�http://blog.csdn.net/zs2538596

	����:��ˬ
	��飺���㷨Ϊ������������ΪO(nlgn)
	���ڣ�07/10/2014

	Author��Shuang Zhang
	Introduction��The algorithm is heap sort, and the worst time is O(nlgn)
	Date : 07/10/2014
*/
#include<stdlib.h>
#include<stdio.h>
#define ARRAY_LENGTH (10)

int left(int i){
	i = 2*i + 1;
	return i;
}

int right(int i){
	i = 2*i + 2;
	return i;
}

void heap_fix(int *A,int i,int heap_size){
	if(A==NULL || i<0){
		printf("Error input\n");
		return ;
	}
	int l = left(i);
	int r = right(i);
	int largest=0;

	if(l<=heap_size && A[l]>A[i]){
		largest = l;
	}else{
		largest = i;
	}

	if(r<=heap_size && A[r]>A[largest]){
		largest = r;
	}

	if(largest != i){
		int temp = A[i];
		A[i] = A[largest];
		A[largest] = temp;
		heap_fix(A,largest,heap_size);
	}
}

void build_heap(int *A,int length){
	if(A==NULL || length<=0){
		printf("Error input\n");
		return;
	}

	int heap_size = length-1;
	for(int i = heap_size/2;i>=0;i--){
		heap_fix(A,i,heap_size);
	}
}

void heap_sort(int *A,int length){
	build_heap(A,length);
	int heap_size = length -1;
	for(int i = length-1 ; i > 0 ; i--){
		int temp = A[0];
		A[0] = A[i];
		A[i] = temp;
		heap_size--;
		heap_fix(A,0,heap_size);
	}
}
int main(){
	int A[ARRAY_LENGTH] ={1,4,5,7,8,9,10,2,3,6};
	heap_sort(A,ARRAY_LENGTH);
	for(int i =0 ; i<ARRAY_LENGTH ; i++){
		printf("num %d : %d \n",i,A[i]);
	}
	system("pause");
	return 0;
}