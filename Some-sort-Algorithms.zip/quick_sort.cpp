/*
	���˲��ͣ�http://blog.csdn.net/zs2538596

	����:��ˬ
	��飺���㷨Ϊ��������������Ϊthita(n^2)������ʱ�临�Ӷ�Ϊthita(nlgn)
	���ڣ�07/10/2014

	Author��Shuang Zhang
	Introduction��The algorithm is quick sort, and the worst time is thita(n^2) , the expected time is thita(nlgn)
	Date : 07/10/2014
*/
#include<stdlib.h>
#include<stdio.h>
#define ARRAY_LENGTH (10)

int partition(int *A,int p,int r){

	if(A==NULL || p<0 || r<0 || p>r){
		return NULL;
	}

	int x = A[r];
	int i = p-1;
	for(int j = p;j < r; j++){
		if(A[j]<=x){
			i = i+1;
			int temp = A[i];
			A[i] = A[j];
			A[j] = temp;
		}
	}
	int temp = A[i+1];
	A[i+1] = A[r];
	A[r] = temp;
	return (i+1);
}

void quick_sort(int *A,int p,int r){

	if(A==NULL || p<0 || r<0 || p>r){
		return;
	}

	if(p < r){
		int q = partition(A,p,r);
		quick_sort(A,p,q-1);
		quick_sort(A,q+1,r);
	}
}

int main(){
	
	int A[ARRAY_LENGTH]={9,2,3,1,4,10,6,5,8,7};
	quick_sort(A,0,ARRAY_LENGTH-1);
	for(int i=0 ; i<ARRAY_LENGTH ; i++){
		printf("num  %d : %d\n",i,A[i]);
	}
	system("pause");
	return 0;
}